<?php

namespace App\Models\api\v1;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'code', 'date', 'due_date', 'branch_id', 'status_id', 'created_id', 'confirmed_id', 'edit_id', 'approved_id', 'production_id', 'driver_id', 'recevied_id'
    ];
}
