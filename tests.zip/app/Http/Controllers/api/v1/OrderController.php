<?php

namespace App\Http\Controllers\api\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\api\v1\Product;
use App\Models\api\v1\Order;
use App\Http\Resources\api\v1\BranchResource;
use App\Http\Resources\api\v1\UserResource;
use Str;
use Carbon\Carbon;

class OrderController extends Controller
{

    public function create()
    {
        $return = [];
        $user = auth()->user();
        $branch = new BranchResource($user->branch);
        $products = $user->branch->client->categories()->with('products')->get();
        $due_date = today()->addDays($branch->due_period);
        $order = Order::where('due_date', $due_date)
                ->whereAnd('branch_id', $branch->id)->first();
        $return['user'] = new UserResource($user);
        $return['branch'] = $branch;
        $return['order'] = $order;
        $return['products'] = $products;
        $return['due_date'] = date('Y-m-d', strtotime($due_date));

        return $return;
    }

}
